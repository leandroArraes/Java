module orientacaoaobjetos4 {
}